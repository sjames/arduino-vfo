
#include "Default.h"
#include "../src/sc_types.h"
#include "DefaultRequired.h"

#include <stdlib.h>
#include <string.h>
/*! \file Implementation of the state machine 'default'
*/

/* prototypes of all internal functions */
static void enact_main_region_initialize(Default* handle);
static void enact_Generator_Initialize(Default* handle);
static void enact_Generator_Running_CLK0_Off(Default* handle);
static void enact_Generator_Running_CLK0_On(Default* handle);
static void enact_Generator_Running_CLK1_Off(Default* handle);
static void enact_Generator_Running_CLK1_On(Default* handle);
static void enact_Generator_Running_CLK2_Off(Default* handle);
static void enact_Generator_Running_CLK2_On(Default* handle);
static void enseq_main_region_initialize_default(Default* handle);
static void enseq_main_region_main_default(Default* handle);
static void enseq_main_region_main_r1_menubar_default(Default* handle);
static void enseq_main_region_main_r1_freq0bar_default(Default* handle);
static void enseq_main_region_main_r1_freq0bar_vforow_Highlighted_default(Default* handle);
static void enseq_main_region_main_r1_freq0bar_vforow_Selected_default(Default* handle);
static void enseq_main_region_main_r1_freq0bar_vforow_SetMultiplier_default(Default* handle);
static void enseq_main_region_main_r1_freq1bar_default(Default* handle);
static void enseq_main_region_main_r1_freq1bar_vforow_Highlighted_default(Default* handle);
static void enseq_main_region_main_r1_freq1bar_vforow_Selected_default(Default* handle);
static void enseq_main_region_main_r1_freq1bar_vforow_SetMultiplier_default(Default* handle);
static void enseq_main_region_main_r1_freq2bar_default(Default* handle);
static void enseq_main_region_main_r1_freq2bar_vforow_Highlighted_default(Default* handle);
static void enseq_main_region_main_r1_freq2bar_vforow_Selected_default(Default* handle);
static void enseq_main_region_main_r1_freq2bar_vforow_SetMultiplier_default(Default* handle);
static void enseq_Generator_Initialize_default(Default* handle);
static void enseq_Generator_Running_default(Default* handle);
static void enseq_Generator_Running_CLK0_Off_default(Default* handle);
static void enseq_Generator_Running_CLK0_On_default(Default* handle);
static void enseq_Generator_Running_CLK1_Off_default(Default* handle);
static void enseq_Generator_Running_CLK1_On_default(Default* handle);
static void enseq_Generator_Running_CLK2_Off_default(Default* handle);
static void enseq_Generator_Running_CLK2_On_default(Default* handle);
static void enseq_main_region_default(Default* handle);
static void enseq_main_region_main_r1_default(Default* handle);
static void enseq_main_region_main_r1_freq0bar_vforow_default(Default* handle);
static void enseq_main_region_main_r1_freq1bar_vforow_default(Default* handle);
static void enseq_main_region_main_r1_freq2bar_vforow_default(Default* handle);
static void enseq_Generator_default(Default* handle);
static void enseq_Generator_Running_CLK0_default(Default* handle);
static void enseq_Generator_Running_CLK1_default(Default* handle);
static void enseq_Generator_Running_CLK2_default(Default* handle);
static void exseq_main_region_initialize(Default* handle);
static void exseq_main_region_main(Default* handle);
static void exseq_main_region_main_r1_menubar(Default* handle);
static void exseq_main_region_main_r1_freq0bar(Default* handle);
static void exseq_main_region_main_r1_freq0bar_vforow_Highlighted(Default* handle);
static void exseq_main_region_main_r1_freq0bar_vforow_Selected(Default* handle);
static void exseq_main_region_main_r1_freq0bar_vforow_SetMultiplier(Default* handle);
static void exseq_main_region_main_r1_freq1bar(Default* handle);
static void exseq_main_region_main_r1_freq1bar_vforow_Highlighted(Default* handle);
static void exseq_main_region_main_r1_freq1bar_vforow_Selected(Default* handle);
static void exseq_main_region_main_r1_freq1bar_vforow_SetMultiplier(Default* handle);
static void exseq_main_region_main_r1_freq2bar(Default* handle);
static void exseq_main_region_main_r1_freq2bar_vforow_Highlighted(Default* handle);
static void exseq_main_region_main_r1_freq2bar_vforow_Selected(Default* handle);
static void exseq_main_region_main_r1_freq2bar_vforow_SetMultiplier(Default* handle);
static void exseq_Generator_Initialize(Default* handle);
static void exseq_Generator_Running_CLK0_Off(Default* handle);
static void exseq_Generator_Running_CLK0_On(Default* handle);
static void exseq_Generator_Running_CLK1_Off(Default* handle);
static void exseq_Generator_Running_CLK1_On(Default* handle);
static void exseq_Generator_Running_CLK2_Off(Default* handle);
static void exseq_Generator_Running_CLK2_On(Default* handle);
static void exseq_main_region(Default* handle);
static void exseq_main_region_main_r1(Default* handle);
static void exseq_main_region_main_r1_freq0bar_vforow(Default* handle);
static void exseq_main_region_main_r1_freq1bar_vforow(Default* handle);
static void exseq_main_region_main_r1_freq2bar_vforow(Default* handle);
static void exseq_Generator(Default* handle);
static void exseq_Generator_Running_CLK0(Default* handle);
static void exseq_Generator_Running_CLK1(Default* handle);
static void exseq_Generator_Running_CLK2(Default* handle);
static void react_main_region__entry_Default(Default* handle);
static void react_main_region_main_r1_freq0bar_vforow__entry_Default(Default* handle);
static void react_main_region_main_r1_freq1bar_vforow__entry_Default(Default* handle);
static void react_main_region_main_r1_freq2bar_vforow__entry_Default(Default* handle);
static void react_main_region_main_r1__entry_Default(Default* handle);
static void react_Generator__entry_Default(Default* handle);
static void react_Generator_Running_CLK0__entry_Default(Default* handle);
static void react_Generator_Running_CLK1__entry_Default(Default* handle);
static void react_Generator_Running_CLK2__entry_Default(Default* handle);
static sc_boolean react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_initialize_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_menubar_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq0bar_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq0bar_vforow_Highlighted_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq0bar_vforow_Selected_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq0bar_vforow_SetMultiplier_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq1bar_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq1bar_vforow_Highlighted_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq1bar_vforow_Selected_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq1bar_vforow_SetMultiplier_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq2bar_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq2bar_vforow_Highlighted_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq2bar_vforow_Selected_react(Default* handle, const sc_boolean try_transition);
static sc_boolean main_region_main_r1_freq2bar_vforow_SetMultiplier_react(Default* handle, const sc_boolean try_transition);
static sc_boolean Generator_Initialize_react(Default* handle, const sc_boolean try_transition);
static sc_boolean Generator_Running_react(Default* handle, const sc_boolean try_transition);
static sc_boolean Generator_Running_CLK0_Off_react(Default* handle, const sc_boolean try_transition);
static sc_boolean Generator_Running_CLK0_On_react(Default* handle, const sc_boolean try_transition);
static sc_boolean Generator_Running_CLK1_Off_react(Default* handle, const sc_boolean try_transition);
static sc_boolean Generator_Running_CLK1_On_react(Default* handle, const sc_boolean try_transition);
static sc_boolean Generator_Running_CLK2_Off_react(Default* handle, const sc_boolean try_transition);
static sc_boolean Generator_Running_CLK2_On_react(Default* handle, const sc_boolean try_transition);
static void clearInEvents(Default* handle);
static void clearOutEvents(Default* handle);


void default_init(Default* handle)
{
	sc_integer i;
	
	for (i = 0; i < DEFAULT_MAX_ORTHOGONAL_STATES; ++i)
	{
		handle->stateConfVector[i] = Default_last_state;
	}
	
	
	handle->stateConfVectorPosition = 0;
	
	clearInEvents(handle);
	clearOutEvents(handle);
	
	/* Default init sequence for statechart default */
	handle->iface.clock0Freq = 0;
	handle->iface.clock1Freq = 0;
	handle->iface.clock2Freq = 0;
	handle->iface.clock0ReqFreq = 70000000;
	handle->iface.clock1ReqFreq = 140000000;
	handle->iface.clock2ReqFreq = 35000000;
	handle->iface.clock0Multiplier = 1;
	handle->iface.clock1Multiplier = 1;
	handle->iface.clock2Multiplier = 1;
}

void default_enter(Default* handle)
{
	/* Default enter sequence for statechart default */
	enseq_main_region_default(handle);
	enseq_Generator_default(handle);
}

void default_runCycle(Default* handle)
{
	clearOutEvents(handle);
	for (handle->stateConfVectorPosition = 0;
		handle->stateConfVectorPosition < DEFAULT_MAX_ORTHOGONAL_STATES;
		handle->stateConfVectorPosition++)
		{
			
		switch (handle->stateConfVector[handle->stateConfVectorPosition])
		{
		case Default_main_region_initialize:
		{
			main_region_initialize_react(handle, bool_true);
			break;
		}
		case Default_main_region_main_r1_menubar:
		{
			main_region_main_r1_menubar_react(handle, bool_true);
			break;
		}
		case Default_main_region_main_r1_freq0bar_vforow_Highlighted:
		{
			main_region_main_r1_freq0bar_vforow_Highlighted_react(handle, bool_true);
			break;
		}
		case Default_main_region_main_r1_freq0bar_vforow_Selected:
		{
			main_region_main_r1_freq0bar_vforow_Selected_react(handle, bool_true);
			break;
		}
		case Default_main_region_main_r1_freq0bar_vforow_SetMultiplier:
		{
			main_region_main_r1_freq0bar_vforow_SetMultiplier_react(handle, bool_true);
			break;
		}
		case Default_main_region_main_r1_freq1bar_vforow_Highlighted:
		{
			main_region_main_r1_freq1bar_vforow_Highlighted_react(handle, bool_true);
			break;
		}
		case Default_main_region_main_r1_freq1bar_vforow_Selected:
		{
			main_region_main_r1_freq1bar_vforow_Selected_react(handle, bool_true);
			break;
		}
		case Default_main_region_main_r1_freq1bar_vforow_SetMultiplier:
		{
			main_region_main_r1_freq1bar_vforow_SetMultiplier_react(handle, bool_true);
			break;
		}
		case Default_main_region_main_r1_freq2bar_vforow_Highlighted:
		{
			main_region_main_r1_freq2bar_vforow_Highlighted_react(handle, bool_true);
			break;
		}
		case Default_main_region_main_r1_freq2bar_vforow_Selected:
		{
			main_region_main_r1_freq2bar_vforow_Selected_react(handle, bool_true);
			break;
		}
		case Default_main_region_main_r1_freq2bar_vforow_SetMultiplier:
		{
			main_region_main_r1_freq2bar_vforow_SetMultiplier_react(handle, bool_true);
			break;
		}
		case Default_Generator_Initialize:
		{
			Generator_Initialize_react(handle, bool_true);
			break;
		}
		case Default_Generator_Running_CLK0_Off:
		{
			Generator_Running_CLK0_Off_react(handle, bool_true);
			break;
		}
		case Default_Generator_Running_CLK0_On:
		{
			Generator_Running_CLK0_On_react(handle, bool_true);
			break;
		}
		case Default_Generator_Running_CLK1_Off:
		{
			Generator_Running_CLK1_Off_react(handle, bool_true);
			break;
		}
		case Default_Generator_Running_CLK1_On:
		{
			Generator_Running_CLK1_On_react(handle, bool_true);
			break;
		}
		case Default_Generator_Running_CLK2_Off:
		{
			Generator_Running_CLK2_Off_react(handle, bool_true);
			break;
		}
		case Default_Generator_Running_CLK2_On:
		{
			Generator_Running_CLK2_On_react(handle, bool_true);
			break;
		}
		default:
			break;
		}
	}
	
	clearInEvents(handle);
}

void default_exit(Default* handle)
{
	/* Default exit sequence for statechart default */
	exseq_main_region(handle);
	exseq_Generator(handle);
}

sc_boolean default_isActive(const Default* handle)
{
	sc_boolean result = bool_false;
	sc_integer i;
	
	for(i = 0; i < DEFAULT_MAX_ORTHOGONAL_STATES; i++)
	{
		result = result || handle->stateConfVector[i] != Default_last_state;
	}
	
	return result;
}

/* 
 * Always returns 'false' since this state machine can never become final.
 */
sc_boolean default_isFinal(const Default* handle)
{
   return bool_false;
}

sc_boolean default_isStateActive(const Default* handle, DefaultStates state)
{
	sc_boolean result = bool_false;
	switch (state)
	{
		case Default_main_region_initialize :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_INITIALIZE] == Default_main_region_initialize
			);
			break;
		case Default_main_region_main :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN] >= Default_main_region_main
				&& handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN] <= Default_main_region_main_r1_freq2bar_vforow_SetMultiplier);
			break;
		case Default_main_region_main_r1_menubar :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_MENUBAR] == Default_main_region_main_r1_menubar
			);
			break;
		case Default_main_region_main_r1_freq0bar :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ0BAR] >= Default_main_region_main_r1_freq0bar
				&& handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ0BAR] <= Default_main_region_main_r1_freq0bar_vforow_SetMultiplier);
			break;
		case Default_main_region_main_r1_freq0bar_vforow_Highlighted :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ0BAR_VFOROW_HIGHLIGHTED] == Default_main_region_main_r1_freq0bar_vforow_Highlighted
			);
			break;
		case Default_main_region_main_r1_freq0bar_vforow_Selected :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ0BAR_VFOROW_SELECTED] == Default_main_region_main_r1_freq0bar_vforow_Selected
			);
			break;
		case Default_main_region_main_r1_freq0bar_vforow_SetMultiplier :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ0BAR_VFOROW_SETMULTIPLIER] == Default_main_region_main_r1_freq0bar_vforow_SetMultiplier
			);
			break;
		case Default_main_region_main_r1_freq1bar :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ1BAR] >= Default_main_region_main_r1_freq1bar
				&& handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ1BAR] <= Default_main_region_main_r1_freq1bar_vforow_SetMultiplier);
			break;
		case Default_main_region_main_r1_freq1bar_vforow_Highlighted :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ1BAR_VFOROW_HIGHLIGHTED] == Default_main_region_main_r1_freq1bar_vforow_Highlighted
			);
			break;
		case Default_main_region_main_r1_freq1bar_vforow_Selected :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ1BAR_VFOROW_SELECTED] == Default_main_region_main_r1_freq1bar_vforow_Selected
			);
			break;
		case Default_main_region_main_r1_freq1bar_vforow_SetMultiplier :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ1BAR_VFOROW_SETMULTIPLIER] == Default_main_region_main_r1_freq1bar_vforow_SetMultiplier
			);
			break;
		case Default_main_region_main_r1_freq2bar :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ2BAR] >= Default_main_region_main_r1_freq2bar
				&& handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ2BAR] <= Default_main_region_main_r1_freq2bar_vforow_SetMultiplier);
			break;
		case Default_main_region_main_r1_freq2bar_vforow_Highlighted :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ2BAR_VFOROW_HIGHLIGHTED] == Default_main_region_main_r1_freq2bar_vforow_Highlighted
			);
			break;
		case Default_main_region_main_r1_freq2bar_vforow_Selected :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ2BAR_VFOROW_SELECTED] == Default_main_region_main_r1_freq2bar_vforow_Selected
			);
			break;
		case Default_main_region_main_r1_freq2bar_vforow_SetMultiplier :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_MAIN_REGION_MAIN_R1_FREQ2BAR_VFOROW_SETMULTIPLIER] == Default_main_region_main_r1_freq2bar_vforow_SetMultiplier
			);
			break;
		case Default_Generator_Initialize :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_GENERATOR_INITIALIZE] == Default_Generator_Initialize
			);
			break;
		case Default_Generator_Running :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_GENERATOR_RUNNING] >= Default_Generator_Running
				&& handle->stateConfVector[SCVI_DEFAULT_GENERATOR_RUNNING] <= Default_Generator_Running_CLK2_On);
			break;
		case Default_Generator_Running_CLK0_Off :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_GENERATOR_RUNNING_CLK0_OFF] == Default_Generator_Running_CLK0_Off
			);
			break;
		case Default_Generator_Running_CLK0_On :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_GENERATOR_RUNNING_CLK0_ON] == Default_Generator_Running_CLK0_On
			);
			break;
		case Default_Generator_Running_CLK1_Off :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_GENERATOR_RUNNING_CLK1_OFF] == Default_Generator_Running_CLK1_Off
			);
			break;
		case Default_Generator_Running_CLK1_On :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_GENERATOR_RUNNING_CLK1_ON] == Default_Generator_Running_CLK1_On
			);
			break;
		case Default_Generator_Running_CLK2_Off :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_GENERATOR_RUNNING_CLK2_OFF] == Default_Generator_Running_CLK2_Off
			);
			break;
		case Default_Generator_Running_CLK2_On :
			result = (sc_boolean) (handle->stateConfVector[SCVI_DEFAULT_GENERATOR_RUNNING_CLK2_ON] == Default_Generator_Running_CLK2_On
			);
			break;
		default:
			result = bool_false;
			break;
	}
	return result;
}

static void clearInEvents(Default* handle)
{
	handle->iface.eReady_raised = bool_false;
	handle->iface.eShortPress_raised = bool_false;
	handle->iface.eLongPress_raised = bool_false;
	handle->iface.eClockWiseTick_raised = bool_false;
	handle->iface.eCounterClockWiseTick_raised = bool_false;
	handle->iface.eUpdateDisplay_raised = bool_false;
	handle->internal.eGeneratorInitialized_raised = bool_false;
	handle->internal.eClock0Toggle_raised = bool_false;
	handle->internal.eClock1Toggle_raised = bool_false;
	handle->internal.eClock2Toggle_raised = bool_false;
	handle->internal.eClockUpdate_raised = bool_false;
}

static void clearOutEvents(Default* handle)
{
}

void defaultIface_raise_eReady(Default* handle)
{
	handle->iface.eReady_raised = bool_true;
}
void defaultIface_raise_eShortPress(Default* handle)
{
	handle->iface.eShortPress_raised = bool_true;
}
void defaultIface_raise_eLongPress(Default* handle)
{
	handle->iface.eLongPress_raised = bool_true;
}
void defaultIface_raise_eClockWiseTick(Default* handle, sc_integer value)
{
	handle->iface.eClockWiseTick_value = value;
	handle->iface.eClockWiseTick_raised = bool_true;
}
void defaultIface_raise_eCounterClockWiseTick(Default* handle, sc_integer value)
{
	handle->iface.eCounterClockWiseTick_value = value;
	handle->iface.eCounterClockWiseTick_raised = bool_true;
}
void defaultIface_raise_eUpdateDisplay(Default* handle)
{
	handle->iface.eUpdateDisplay_raised = bool_true;
}


sc_integer defaultIface_get_clock0Freq(const Default* handle)
{
	return handle->iface.clock0Freq;
}
void defaultIface_set_clock0Freq(Default* handle, sc_integer value)
{
	handle->iface.clock0Freq = value;
}
sc_integer defaultIface_get_clock1Freq(const Default* handle)
{
	return handle->iface.clock1Freq;
}
void defaultIface_set_clock1Freq(Default* handle, sc_integer value)
{
	handle->iface.clock1Freq = value;
}
sc_integer defaultIface_get_clock2Freq(const Default* handle)
{
	return handle->iface.clock2Freq;
}
void defaultIface_set_clock2Freq(Default* handle, sc_integer value)
{
	handle->iface.clock2Freq = value;
}
sc_integer defaultIface_get_clock0ReqFreq(const Default* handle)
{
	return handle->iface.clock0ReqFreq;
}
void defaultIface_set_clock0ReqFreq(Default* handle, sc_integer value)
{
	handle->iface.clock0ReqFreq = value;
}
sc_integer defaultIface_get_clock1ReqFreq(const Default* handle)
{
	return handle->iface.clock1ReqFreq;
}
void defaultIface_set_clock1ReqFreq(Default* handle, sc_integer value)
{
	handle->iface.clock1ReqFreq = value;
}
sc_integer defaultIface_get_clock2ReqFreq(const Default* handle)
{
	return handle->iface.clock2ReqFreq;
}
void defaultIface_set_clock2ReqFreq(Default* handle, sc_integer value)
{
	handle->iface.clock2ReqFreq = value;
}
sc_integer defaultIface_get_clock0Multiplier(const Default* handle)
{
	return handle->iface.clock0Multiplier;
}
void defaultIface_set_clock0Multiplier(Default* handle, sc_integer value)
{
	handle->iface.clock0Multiplier = value;
}
sc_integer defaultIface_get_clock1Multiplier(const Default* handle)
{
	return handle->iface.clock1Multiplier;
}
void defaultIface_set_clock1Multiplier(Default* handle, sc_integer value)
{
	handle->iface.clock1Multiplier = value;
}
sc_integer defaultIface_get_clock2Multiplier(const Default* handle)
{
	return handle->iface.clock2Multiplier;
}
void defaultIface_set_clock2Multiplier(Default* handle, sc_integer value)
{
	handle->iface.clock2Multiplier = value;
}

/* implementations of all internal functions */

/* Entry action for state 'initialize'. */
static void enact_main_region_initialize(Default* handle)
{
	/* Entry action for state 'initialize'. */
	defaultIface_updateDisplay(handle);
	handle->iface.eReady_raised = bool_true;
}

/* Entry action for state 'Initialize'. */
static void enact_Generator_Initialize(Default* handle)
{
	/* Entry action for state 'Initialize'. */
	handle->internal.eGeneratorInitialized_raised = bool_true;
}

/* Entry action for state 'Off'. */
static void enact_Generator_Running_CLK0_Off(Default* handle)
{
	/* Entry action for state 'Off'. */
	defaultIface_disableClock(handle, 0);
}

/* Entry action for state 'On'. */
static void enact_Generator_Running_CLK0_On(Default* handle)
{
	/* Entry action for state 'On'. */
	defaultIface_updateClock(handle, 0);
	defaultIface_enableClock(handle, 0);
}

/* Entry action for state 'Off'. */
static void enact_Generator_Running_CLK1_Off(Default* handle)
{
	/* Entry action for state 'Off'. */
	defaultIface_disableClock(handle, 1);
}

/* Entry action for state 'On'. */
static void enact_Generator_Running_CLK1_On(Default* handle)
{
	/* Entry action for state 'On'. */
	defaultIface_updateClock(handle, 1);
	defaultIface_enableClock(handle, 1);
}

/* Entry action for state 'Off'. */
static void enact_Generator_Running_CLK2_Off(Default* handle)
{
	/* Entry action for state 'Off'. */
	defaultIface_disableClock(handle, 2);
}

/* Entry action for state 'On'. */
static void enact_Generator_Running_CLK2_On(Default* handle)
{
	/* Entry action for state 'On'. */
	defaultIface_updateClock(handle, 2);
	defaultIface_enableClock(handle, 2);
}

/* 'default' enter sequence for state initialize */
static void enseq_main_region_initialize_default(Default* handle)
{
	/* 'default' enter sequence for state initialize */
	enact_main_region_initialize(handle);
	handle->stateConfVector[0] = Default_main_region_initialize;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state main */
static void enseq_main_region_main_default(Default* handle)
{
	/* 'default' enter sequence for state main */
	enseq_main_region_main_r1_default(handle);
}

/* 'default' enter sequence for state menubar */
static void enseq_main_region_main_r1_menubar_default(Default* handle)
{
	/* 'default' enter sequence for state menubar */
	handle->stateConfVector[0] = Default_main_region_main_r1_menubar;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state freq0bar */
static void enseq_main_region_main_r1_freq0bar_default(Default* handle)
{
	/* 'default' enter sequence for state freq0bar */
	enseq_main_region_main_r1_freq0bar_vforow_default(handle);
}

/* 'default' enter sequence for state Highlighted */
static void enseq_main_region_main_r1_freq0bar_vforow_Highlighted_default(Default* handle)
{
	/* 'default' enter sequence for state Highlighted */
	handle->stateConfVector[0] = Default_main_region_main_r1_freq0bar_vforow_Highlighted;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state Selected */
static void enseq_main_region_main_r1_freq0bar_vforow_Selected_default(Default* handle)
{
	/* 'default' enter sequence for state Selected */
	handle->stateConfVector[0] = Default_main_region_main_r1_freq0bar_vforow_Selected;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state SetMultiplier */
static void enseq_main_region_main_r1_freq0bar_vforow_SetMultiplier_default(Default* handle)
{
	/* 'default' enter sequence for state SetMultiplier */
	handle->stateConfVector[0] = Default_main_region_main_r1_freq0bar_vforow_SetMultiplier;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state freq1bar */
static void enseq_main_region_main_r1_freq1bar_default(Default* handle)
{
	/* 'default' enter sequence for state freq1bar */
	enseq_main_region_main_r1_freq1bar_vforow_default(handle);
}

/* 'default' enter sequence for state Highlighted */
static void enseq_main_region_main_r1_freq1bar_vforow_Highlighted_default(Default* handle)
{
	/* 'default' enter sequence for state Highlighted */
	handle->stateConfVector[0] = Default_main_region_main_r1_freq1bar_vforow_Highlighted;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state Selected */
static void enseq_main_region_main_r1_freq1bar_vforow_Selected_default(Default* handle)
{
	/* 'default' enter sequence for state Selected */
	handle->stateConfVector[0] = Default_main_region_main_r1_freq1bar_vforow_Selected;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state SetMultiplier */
static void enseq_main_region_main_r1_freq1bar_vforow_SetMultiplier_default(Default* handle)
{
	/* 'default' enter sequence for state SetMultiplier */
	handle->stateConfVector[0] = Default_main_region_main_r1_freq1bar_vforow_SetMultiplier;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state freq2bar */
static void enseq_main_region_main_r1_freq2bar_default(Default* handle)
{
	/* 'default' enter sequence for state freq2bar */
	enseq_main_region_main_r1_freq2bar_vforow_default(handle);
}

/* 'default' enter sequence for state Highlighted */
static void enseq_main_region_main_r1_freq2bar_vforow_Highlighted_default(Default* handle)
{
	/* 'default' enter sequence for state Highlighted */
	handle->stateConfVector[0] = Default_main_region_main_r1_freq2bar_vforow_Highlighted;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state Selected */
static void enseq_main_region_main_r1_freq2bar_vforow_Selected_default(Default* handle)
{
	/* 'default' enter sequence for state Selected */
	handle->stateConfVector[0] = Default_main_region_main_r1_freq2bar_vforow_Selected;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state SetMultiplier */
static void enseq_main_region_main_r1_freq2bar_vforow_SetMultiplier_default(Default* handle)
{
	/* 'default' enter sequence for state SetMultiplier */
	handle->stateConfVector[0] = Default_main_region_main_r1_freq2bar_vforow_SetMultiplier;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state Initialize */
static void enseq_Generator_Initialize_default(Default* handle)
{
	/* 'default' enter sequence for state Initialize */
	enact_Generator_Initialize(handle);
	handle->stateConfVector[1] = Default_Generator_Initialize;
	handle->stateConfVectorPosition = 1;
}

/* 'default' enter sequence for state Running */
static void enseq_Generator_Running_default(Default* handle)
{
	/* 'default' enter sequence for state Running */
	enseq_Generator_Running_CLK0_default(handle);
	enseq_Generator_Running_CLK1_default(handle);
	enseq_Generator_Running_CLK2_default(handle);
}

/* 'default' enter sequence for state Off */
static void enseq_Generator_Running_CLK0_Off_default(Default* handle)
{
	/* 'default' enter sequence for state Off */
	enact_Generator_Running_CLK0_Off(handle);
	handle->stateConfVector[1] = Default_Generator_Running_CLK0_Off;
	handle->stateConfVectorPosition = 1;
}

/* 'default' enter sequence for state On */
static void enseq_Generator_Running_CLK0_On_default(Default* handle)
{
	/* 'default' enter sequence for state On */
	enact_Generator_Running_CLK0_On(handle);
	handle->stateConfVector[1] = Default_Generator_Running_CLK0_On;
	handle->stateConfVectorPosition = 1;
}

/* 'default' enter sequence for state Off */
static void enseq_Generator_Running_CLK1_Off_default(Default* handle)
{
	/* 'default' enter sequence for state Off */
	enact_Generator_Running_CLK1_Off(handle);
	handle->stateConfVector[2] = Default_Generator_Running_CLK1_Off;
	handle->stateConfVectorPosition = 2;
}

/* 'default' enter sequence for state On */
static void enseq_Generator_Running_CLK1_On_default(Default* handle)
{
	/* 'default' enter sequence for state On */
	enact_Generator_Running_CLK1_On(handle);
	handle->stateConfVector[2] = Default_Generator_Running_CLK1_On;
	handle->stateConfVectorPosition = 2;
}

/* 'default' enter sequence for state Off */
static void enseq_Generator_Running_CLK2_Off_default(Default* handle)
{
	/* 'default' enter sequence for state Off */
	enact_Generator_Running_CLK2_Off(handle);
	handle->stateConfVector[3] = Default_Generator_Running_CLK2_Off;
	handle->stateConfVectorPosition = 3;
}

/* 'default' enter sequence for state On */
static void enseq_Generator_Running_CLK2_On_default(Default* handle)
{
	/* 'default' enter sequence for state On */
	enact_Generator_Running_CLK2_On(handle);
	handle->stateConfVector[3] = Default_Generator_Running_CLK2_On;
	handle->stateConfVectorPosition = 3;
}

/* 'default' enter sequence for region main region */
static void enseq_main_region_default(Default* handle)
{
	/* 'default' enter sequence for region main region */
	react_main_region__entry_Default(handle);
}

/* 'default' enter sequence for region r1 */
static void enseq_main_region_main_r1_default(Default* handle)
{
	/* 'default' enter sequence for region r1 */
	react_main_region_main_r1__entry_Default(handle);
}

/* 'default' enter sequence for region vforow */
static void enseq_main_region_main_r1_freq0bar_vforow_default(Default* handle)
{
	/* 'default' enter sequence for region vforow */
	react_main_region_main_r1_freq0bar_vforow__entry_Default(handle);
}

/* 'default' enter sequence for region vforow */
static void enseq_main_region_main_r1_freq1bar_vforow_default(Default* handle)
{
	/* 'default' enter sequence for region vforow */
	react_main_region_main_r1_freq1bar_vforow__entry_Default(handle);
}

/* 'default' enter sequence for region vforow */
static void enseq_main_region_main_r1_freq2bar_vforow_default(Default* handle)
{
	/* 'default' enter sequence for region vforow */
	react_main_region_main_r1_freq2bar_vforow__entry_Default(handle);
}

/* 'default' enter sequence for region Generator */
static void enseq_Generator_default(Default* handle)
{
	/* 'default' enter sequence for region Generator */
	react_Generator__entry_Default(handle);
}

/* 'default' enter sequence for region CLK0 */
static void enseq_Generator_Running_CLK0_default(Default* handle)
{
	/* 'default' enter sequence for region CLK0 */
	react_Generator_Running_CLK0__entry_Default(handle);
}

/* 'default' enter sequence for region CLK1 */
static void enseq_Generator_Running_CLK1_default(Default* handle)
{
	/* 'default' enter sequence for region CLK1 */
	react_Generator_Running_CLK1__entry_Default(handle);
}

/* 'default' enter sequence for region CLK2 */
static void enseq_Generator_Running_CLK2_default(Default* handle)
{
	/* 'default' enter sequence for region CLK2 */
	react_Generator_Running_CLK2__entry_Default(handle);
}

/* Default exit sequence for state initialize */
static void exseq_main_region_initialize(Default* handle)
{
	/* Default exit sequence for state initialize */
	handle->stateConfVector[0] = Default_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state main */
static void exseq_main_region_main(Default* handle)
{
	/* Default exit sequence for state main */
	exseq_main_region_main_r1(handle);
}

/* Default exit sequence for state menubar */
static void exseq_main_region_main_r1_menubar(Default* handle)
{
	/* Default exit sequence for state menubar */
	handle->stateConfVector[0] = Default_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state freq0bar */
static void exseq_main_region_main_r1_freq0bar(Default* handle)
{
	/* Default exit sequence for state freq0bar */
	exseq_main_region_main_r1_freq0bar_vforow(handle);
}

/* Default exit sequence for state Highlighted */
static void exseq_main_region_main_r1_freq0bar_vforow_Highlighted(Default* handle)
{
	/* Default exit sequence for state Highlighted */
	handle->stateConfVector[0] = Default_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state Selected */
static void exseq_main_region_main_r1_freq0bar_vforow_Selected(Default* handle)
{
	/* Default exit sequence for state Selected */
	handle->stateConfVector[0] = Default_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state SetMultiplier */
static void exseq_main_region_main_r1_freq0bar_vforow_SetMultiplier(Default* handle)
{
	/* Default exit sequence for state SetMultiplier */
	handle->stateConfVector[0] = Default_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state freq1bar */
static void exseq_main_region_main_r1_freq1bar(Default* handle)
{
	/* Default exit sequence for state freq1bar */
	exseq_main_region_main_r1_freq1bar_vforow(handle);
}

/* Default exit sequence for state Highlighted */
static void exseq_main_region_main_r1_freq1bar_vforow_Highlighted(Default* handle)
{
	/* Default exit sequence for state Highlighted */
	handle->stateConfVector[0] = Default_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state Selected */
static void exseq_main_region_main_r1_freq1bar_vforow_Selected(Default* handle)
{
	/* Default exit sequence for state Selected */
	handle->stateConfVector[0] = Default_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state SetMultiplier */
static void exseq_main_region_main_r1_freq1bar_vforow_SetMultiplier(Default* handle)
{
	/* Default exit sequence for state SetMultiplier */
	handle->stateConfVector[0] = Default_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state freq2bar */
static void exseq_main_region_main_r1_freq2bar(Default* handle)
{
	/* Default exit sequence for state freq2bar */
	exseq_main_region_main_r1_freq2bar_vforow(handle);
}

/* Default exit sequence for state Highlighted */
static void exseq_main_region_main_r1_freq2bar_vforow_Highlighted(Default* handle)
{
	/* Default exit sequence for state Highlighted */
	handle->stateConfVector[0] = Default_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state Selected */
static void exseq_main_region_main_r1_freq2bar_vforow_Selected(Default* handle)
{
	/* Default exit sequence for state Selected */
	handle->stateConfVector[0] = Default_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state SetMultiplier */
static void exseq_main_region_main_r1_freq2bar_vforow_SetMultiplier(Default* handle)
{
	/* Default exit sequence for state SetMultiplier */
	handle->stateConfVector[0] = Default_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state Initialize */
static void exseq_Generator_Initialize(Default* handle)
{
	/* Default exit sequence for state Initialize */
	handle->stateConfVector[1] = Default_last_state;
	handle->stateConfVectorPosition = 1;
}

/* Default exit sequence for state Off */
static void exseq_Generator_Running_CLK0_Off(Default* handle)
{
	/* Default exit sequence for state Off */
	handle->stateConfVector[1] = Default_last_state;
	handle->stateConfVectorPosition = 1;
}

/* Default exit sequence for state On */
static void exseq_Generator_Running_CLK0_On(Default* handle)
{
	/* Default exit sequence for state On */
	handle->stateConfVector[1] = Default_last_state;
	handle->stateConfVectorPosition = 1;
}

/* Default exit sequence for state Off */
static void exseq_Generator_Running_CLK1_Off(Default* handle)
{
	/* Default exit sequence for state Off */
	handle->stateConfVector[2] = Default_last_state;
	handle->stateConfVectorPosition = 2;
}

/* Default exit sequence for state On */
static void exseq_Generator_Running_CLK1_On(Default* handle)
{
	/* Default exit sequence for state On */
	handle->stateConfVector[2] = Default_last_state;
	handle->stateConfVectorPosition = 2;
}

/* Default exit sequence for state Off */
static void exseq_Generator_Running_CLK2_Off(Default* handle)
{
	/* Default exit sequence for state Off */
	handle->stateConfVector[3] = Default_last_state;
	handle->stateConfVectorPosition = 3;
}

/* Default exit sequence for state On */
static void exseq_Generator_Running_CLK2_On(Default* handle)
{
	/* Default exit sequence for state On */
	handle->stateConfVector[3] = Default_last_state;
	handle->stateConfVectorPosition = 3;
}

/* Default exit sequence for region main region */
static void exseq_main_region(Default* handle)
{
	/* Default exit sequence for region main region */
	/* Handle exit of all possible states (of default.main_region) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Default_main_region_initialize :
		{
			exseq_main_region_initialize(handle);
			break;
		}
		case Default_main_region_main_r1_menubar :
		{
			exseq_main_region_main_r1_menubar(handle);
			break;
		}
		case Default_main_region_main_r1_freq0bar_vforow_Highlighted :
		{
			exseq_main_region_main_r1_freq0bar_vforow_Highlighted(handle);
			break;
		}
		case Default_main_region_main_r1_freq0bar_vforow_Selected :
		{
			exseq_main_region_main_r1_freq0bar_vforow_Selected(handle);
			break;
		}
		case Default_main_region_main_r1_freq0bar_vforow_SetMultiplier :
		{
			exseq_main_region_main_r1_freq0bar_vforow_SetMultiplier(handle);
			break;
		}
		case Default_main_region_main_r1_freq1bar_vforow_Highlighted :
		{
			exseq_main_region_main_r1_freq1bar_vforow_Highlighted(handle);
			break;
		}
		case Default_main_region_main_r1_freq1bar_vforow_Selected :
		{
			exseq_main_region_main_r1_freq1bar_vforow_Selected(handle);
			break;
		}
		case Default_main_region_main_r1_freq1bar_vforow_SetMultiplier :
		{
			exseq_main_region_main_r1_freq1bar_vforow_SetMultiplier(handle);
			break;
		}
		case Default_main_region_main_r1_freq2bar_vforow_Highlighted :
		{
			exseq_main_region_main_r1_freq2bar_vforow_Highlighted(handle);
			break;
		}
		case Default_main_region_main_r1_freq2bar_vforow_Selected :
		{
			exseq_main_region_main_r1_freq2bar_vforow_Selected(handle);
			break;
		}
		case Default_main_region_main_r1_freq2bar_vforow_SetMultiplier :
		{
			exseq_main_region_main_r1_freq2bar_vforow_SetMultiplier(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region r1 */
static void exseq_main_region_main_r1(Default* handle)
{
	/* Default exit sequence for region r1 */
	/* Handle exit of all possible states (of default.main_region.main.r1) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Default_main_region_main_r1_menubar :
		{
			exseq_main_region_main_r1_menubar(handle);
			break;
		}
		case Default_main_region_main_r1_freq0bar_vforow_Highlighted :
		{
			exseq_main_region_main_r1_freq0bar_vforow_Highlighted(handle);
			break;
		}
		case Default_main_region_main_r1_freq0bar_vforow_Selected :
		{
			exseq_main_region_main_r1_freq0bar_vforow_Selected(handle);
			break;
		}
		case Default_main_region_main_r1_freq0bar_vforow_SetMultiplier :
		{
			exseq_main_region_main_r1_freq0bar_vforow_SetMultiplier(handle);
			break;
		}
		case Default_main_region_main_r1_freq1bar_vforow_Highlighted :
		{
			exseq_main_region_main_r1_freq1bar_vforow_Highlighted(handle);
			break;
		}
		case Default_main_region_main_r1_freq1bar_vforow_Selected :
		{
			exseq_main_region_main_r1_freq1bar_vforow_Selected(handle);
			break;
		}
		case Default_main_region_main_r1_freq1bar_vforow_SetMultiplier :
		{
			exseq_main_region_main_r1_freq1bar_vforow_SetMultiplier(handle);
			break;
		}
		case Default_main_region_main_r1_freq2bar_vforow_Highlighted :
		{
			exseq_main_region_main_r1_freq2bar_vforow_Highlighted(handle);
			break;
		}
		case Default_main_region_main_r1_freq2bar_vforow_Selected :
		{
			exseq_main_region_main_r1_freq2bar_vforow_Selected(handle);
			break;
		}
		case Default_main_region_main_r1_freq2bar_vforow_SetMultiplier :
		{
			exseq_main_region_main_r1_freq2bar_vforow_SetMultiplier(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region vforow */
static void exseq_main_region_main_r1_freq0bar_vforow(Default* handle)
{
	/* Default exit sequence for region vforow */
	/* Handle exit of all possible states (of default.main_region.main.r1.freq0bar.vforow) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Default_main_region_main_r1_freq0bar_vforow_Highlighted :
		{
			exseq_main_region_main_r1_freq0bar_vforow_Highlighted(handle);
			break;
		}
		case Default_main_region_main_r1_freq0bar_vforow_Selected :
		{
			exseq_main_region_main_r1_freq0bar_vforow_Selected(handle);
			break;
		}
		case Default_main_region_main_r1_freq0bar_vforow_SetMultiplier :
		{
			exseq_main_region_main_r1_freq0bar_vforow_SetMultiplier(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region vforow */
static void exseq_main_region_main_r1_freq1bar_vforow(Default* handle)
{
	/* Default exit sequence for region vforow */
	/* Handle exit of all possible states (of default.main_region.main.r1.freq1bar.vforow) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Default_main_region_main_r1_freq1bar_vforow_Highlighted :
		{
			exseq_main_region_main_r1_freq1bar_vforow_Highlighted(handle);
			break;
		}
		case Default_main_region_main_r1_freq1bar_vforow_Selected :
		{
			exseq_main_region_main_r1_freq1bar_vforow_Selected(handle);
			break;
		}
		case Default_main_region_main_r1_freq1bar_vforow_SetMultiplier :
		{
			exseq_main_region_main_r1_freq1bar_vforow_SetMultiplier(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region vforow */
static void exseq_main_region_main_r1_freq2bar_vforow(Default* handle)
{
	/* Default exit sequence for region vforow */
	/* Handle exit of all possible states (of default.main_region.main.r1.freq2bar.vforow) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Default_main_region_main_r1_freq2bar_vforow_Highlighted :
		{
			exseq_main_region_main_r1_freq2bar_vforow_Highlighted(handle);
			break;
		}
		case Default_main_region_main_r1_freq2bar_vforow_Selected :
		{
			exseq_main_region_main_r1_freq2bar_vforow_Selected(handle);
			break;
		}
		case Default_main_region_main_r1_freq2bar_vforow_SetMultiplier :
		{
			exseq_main_region_main_r1_freq2bar_vforow_SetMultiplier(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region Generator */
static void exseq_Generator(Default* handle)
{
	/* Default exit sequence for region Generator */
	/* Handle exit of all possible states (of default.Generator) at position 1... */
	switch(handle->stateConfVector[ 1 ])
	{
		case Default_Generator_Initialize :
		{
			exseq_Generator_Initialize(handle);
			break;
		}
		case Default_Generator_Running_CLK0_Off :
		{
			exseq_Generator_Running_CLK0_Off(handle);
			break;
		}
		case Default_Generator_Running_CLK0_On :
		{
			exseq_Generator_Running_CLK0_On(handle);
			break;
		}
		default: break;
	}
	/* Handle exit of all possible states (of default.Generator) at position 2... */
	switch(handle->stateConfVector[ 2 ])
	{
		case Default_Generator_Running_CLK1_Off :
		{
			exseq_Generator_Running_CLK1_Off(handle);
			break;
		}
		case Default_Generator_Running_CLK1_On :
		{
			exseq_Generator_Running_CLK1_On(handle);
			break;
		}
		default: break;
	}
	/* Handle exit of all possible states (of default.Generator) at position 3... */
	switch(handle->stateConfVector[ 3 ])
	{
		case Default_Generator_Running_CLK2_Off :
		{
			exseq_Generator_Running_CLK2_Off(handle);
			break;
		}
		case Default_Generator_Running_CLK2_On :
		{
			exseq_Generator_Running_CLK2_On(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region CLK0 */
static void exseq_Generator_Running_CLK0(Default* handle)
{
	/* Default exit sequence for region CLK0 */
	/* Handle exit of all possible states (of default.Generator.Running.CLK0) at position 1... */
	switch(handle->stateConfVector[ 1 ])
	{
		case Default_Generator_Running_CLK0_Off :
		{
			exseq_Generator_Running_CLK0_Off(handle);
			break;
		}
		case Default_Generator_Running_CLK0_On :
		{
			exseq_Generator_Running_CLK0_On(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region CLK1 */
static void exseq_Generator_Running_CLK1(Default* handle)
{
	/* Default exit sequence for region CLK1 */
	/* Handle exit of all possible states (of default.Generator.Running.CLK1) at position 2... */
	switch(handle->stateConfVector[ 2 ])
	{
		case Default_Generator_Running_CLK1_Off :
		{
			exseq_Generator_Running_CLK1_Off(handle);
			break;
		}
		case Default_Generator_Running_CLK1_On :
		{
			exseq_Generator_Running_CLK1_On(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region CLK2 */
static void exseq_Generator_Running_CLK2(Default* handle)
{
	/* Default exit sequence for region CLK2 */
	/* Handle exit of all possible states (of default.Generator.Running.CLK2) at position 3... */
	switch(handle->stateConfVector[ 3 ])
	{
		case Default_Generator_Running_CLK2_Off :
		{
			exseq_Generator_Running_CLK2_Off(handle);
			break;
		}
		case Default_Generator_Running_CLK2_On :
		{
			exseq_Generator_Running_CLK2_On(handle);
			break;
		}
		default: break;
	}
}

/* Default react sequence for initial entry  */
static void react_main_region__entry_Default(Default* handle)
{
	/* Default react sequence for initial entry  */
	enseq_main_region_initialize_default(handle);
}

/* Default react sequence for initial entry  */
static void react_main_region_main_r1_freq0bar_vforow__entry_Default(Default* handle)
{
	/* Default react sequence for initial entry  */
	enseq_main_region_main_r1_freq0bar_vforow_Highlighted_default(handle);
}

/* Default react sequence for initial entry  */
static void react_main_region_main_r1_freq1bar_vforow__entry_Default(Default* handle)
{
	/* Default react sequence for initial entry  */
	enseq_main_region_main_r1_freq1bar_vforow_Highlighted_default(handle);
}

/* Default react sequence for initial entry  */
static void react_main_region_main_r1_freq2bar_vforow__entry_Default(Default* handle)
{
	/* Default react sequence for initial entry  */
	enseq_main_region_main_r1_freq2bar_vforow_Highlighted_default(handle);
}

/* Default react sequence for initial entry  */
static void react_main_region_main_r1__entry_Default(Default* handle)
{
	/* Default react sequence for initial entry  */
	enseq_main_region_main_r1_freq1bar_default(handle);
}

/* Default react sequence for initial entry  */
static void react_Generator__entry_Default(Default* handle)
{
	/* Default react sequence for initial entry  */
	enseq_Generator_Initialize_default(handle);
}

/* Default react sequence for initial entry  */
static void react_Generator_Running_CLK0__entry_Default(Default* handle)
{
	/* Default react sequence for initial entry  */
	enseq_Generator_Running_CLK0_Off_default(handle);
}

/* Default react sequence for initial entry  */
static void react_Generator_Running_CLK1__entry_Default(Default* handle)
{
	/* Default react sequence for initial entry  */
	enseq_Generator_Running_CLK1_Off_default(handle);
}

/* Default react sequence for initial entry  */
static void react_Generator_Running_CLK2__entry_Default(Default* handle)
{
	/* Default react sequence for initial entry  */
	enseq_Generator_Running_CLK2_Off_default(handle);
}

static sc_boolean react(Default* handle, const sc_boolean try_transition) {
	/* State machine reactions. */
	return bool_false;
}

static sc_boolean main_region_initialize_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state initialize. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eReady_raised == bool_true)
		{ 
			exseq_main_region_initialize(handle);
			enseq_main_region_main_default(handle);
		}  else
		{
			did_transition = bool_false;
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
	} 
	return did_transition;
}

static sc_boolean main_region_main_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state main. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eUpdateDisplay_raised == bool_true)
		{ 
			exseq_main_region_main(handle);
			defaultIface_updateDisplay(handle);
			enseq_main_region_main_default(handle);
		}  else
		{
			did_transition = bool_false;
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_menubar_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state menubar. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eCounterClockWiseTick_raised == bool_true)
		{ 
			exseq_main_region_main_r1_menubar(handle);
			enseq_main_region_main_r1_freq2bar_default(handle);
			main_region_main_react(handle, bool_false);
		}  else
		{
			did_transition = bool_false;
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq0bar_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state freq0bar. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eCounterClockWiseTick_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq0bar(handle);
			enseq_main_region_main_r1_menubar_default(handle);
			main_region_main_react(handle, bool_false);
		}  else
		{
			if (handle->iface.eClockWiseTick_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq0bar(handle);
				enseq_main_region_main_r1_freq1bar_default(handle);
				main_region_main_react(handle, bool_false);
			}  else
			{
				did_transition = bool_false;
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq0bar_vforow_Highlighted_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state Highlighted. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eLongPress_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq0bar_vforow_Highlighted(handle);
			enseq_main_region_main_r1_freq0bar_vforow_Selected_default(handle);
			main_region_main_r1_freq0bar_react(handle, bool_false);
		}  else
		{
			if (handle->iface.eShortPress_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq0bar_vforow_Highlighted(handle);
				handle->internal.eClock0Toggle_raised = bool_true;
				enseq_main_region_main_r1_freq0bar_vforow_Highlighted_default(handle);
			}  else
			{
				did_transition = bool_false;
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_r1_freq0bar_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq0bar_vforow_Selected_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state Selected. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eCounterClockWiseTick_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq0bar_vforow_Selected(handle);
			handle->iface.clock0ReqFreq = handle->iface.clock0ReqFreq - handle->iface.clock0Multiplier;
			handle->internal.eClockUpdate_raised = bool_true;
			enseq_main_region_main_r1_freq0bar_vforow_Selected_default(handle);
		}  else
		{
			if (handle->iface.eClockWiseTick_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq0bar_vforow_Selected(handle);
				handle->iface.clock0ReqFreq = handle->iface.clock0ReqFreq + handle->iface.clock0Multiplier;
				handle->internal.eClockUpdate_raised = bool_true;
				enseq_main_region_main_r1_freq0bar_vforow_Selected_default(handle);
			}  else
			{
				if (handle->iface.eLongPress_raised == bool_true)
				{ 
					exseq_main_region_main_r1_freq0bar_vforow_Selected(handle);
					enseq_main_region_main_r1_freq0bar_vforow_Highlighted_default(handle);
					main_region_main_r1_freq0bar_react(handle, bool_false);
				}  else
				{
					if (handle->iface.eShortPress_raised == bool_true)
					{ 
						exseq_main_region_main_r1_freq0bar_vforow_Selected(handle);
						enseq_main_region_main_r1_freq0bar_vforow_SetMultiplier_default(handle);
						main_region_main_r1_freq0bar_react(handle, bool_false);
					}  else
					{
						did_transition = bool_false;
					}
				}
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_r1_freq0bar_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq0bar_vforow_SetMultiplier_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state SetMultiplier. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eShortPress_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq0bar_vforow_SetMultiplier(handle);
			enseq_main_region_main_r1_freq0bar_vforow_Selected_default(handle);
			main_region_main_r1_freq0bar_react(handle, bool_false);
		}  else
		{
			if (handle->iface.eClockWiseTick_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq0bar_vforow_SetMultiplier(handle);
				handle->iface.clock0Multiplier = (handle->iface.clock0Multiplier) != (1) ? handle->iface.clock0Multiplier / 10 : handle->iface.clock0Multiplier;
				enseq_main_region_main_r1_freq0bar_vforow_SetMultiplier_default(handle);
			}  else
			{
				if (handle->iface.eCounterClockWiseTick_raised == bool_true)
				{ 
					exseq_main_region_main_r1_freq0bar_vforow_SetMultiplier(handle);
					handle->iface.clock0Multiplier = (handle->iface.clock0Multiplier) != (1000000) ? handle->iface.clock0Multiplier * 10 : handle->iface.clock0Multiplier;
					enseq_main_region_main_r1_freq0bar_vforow_SetMultiplier_default(handle);
				}  else
				{
					if (handle->iface.eLongPress_raised == bool_true)
					{ 
						exseq_main_region_main_r1_freq0bar_vforow_SetMultiplier(handle);
						enseq_main_region_main_r1_freq0bar_vforow_Highlighted_default(handle);
						main_region_main_r1_freq0bar_react(handle, bool_false);
					}  else
					{
						did_transition = bool_false;
					}
				}
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_r1_freq0bar_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq1bar_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state freq1bar. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eClockWiseTick_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq1bar(handle);
			enseq_main_region_main_r1_freq2bar_default(handle);
			main_region_main_react(handle, bool_false);
		}  else
		{
			if (handle->iface.eCounterClockWiseTick_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq1bar(handle);
				enseq_main_region_main_r1_freq0bar_default(handle);
				main_region_main_react(handle, bool_false);
			}  else
			{
				did_transition = bool_false;
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq1bar_vforow_Highlighted_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state Highlighted. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eLongPress_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq1bar_vforow_Highlighted(handle);
			enseq_main_region_main_r1_freq1bar_vforow_Selected_default(handle);
			main_region_main_r1_freq1bar_react(handle, bool_false);
		}  else
		{
			if (handle->iface.eShortPress_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq1bar_vforow_Highlighted(handle);
				handle->internal.eClock1Toggle_raised = bool_true;
				enseq_main_region_main_r1_freq1bar_vforow_Highlighted_default(handle);
			}  else
			{
				did_transition = bool_false;
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_r1_freq1bar_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq1bar_vforow_Selected_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state Selected. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eCounterClockWiseTick_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq1bar_vforow_Selected(handle);
			handle->iface.clock1ReqFreq = handle->iface.clock1ReqFreq - handle->iface.clock1Multiplier;
			handle->internal.eClockUpdate_raised = bool_true;
			enseq_main_region_main_r1_freq1bar_vforow_Selected_default(handle);
		}  else
		{
			if (handle->iface.eClockWiseTick_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq1bar_vforow_Selected(handle);
				handle->iface.clock1ReqFreq = handle->iface.clock1ReqFreq + handle->iface.clock1Multiplier;
				handle->internal.eClockUpdate_raised = bool_true;
				enseq_main_region_main_r1_freq1bar_vforow_Selected_default(handle);
			}  else
			{
				if (handle->iface.eLongPress_raised == bool_true)
				{ 
					exseq_main_region_main_r1_freq1bar_vforow_Selected(handle);
					enseq_main_region_main_r1_freq1bar_vforow_Highlighted_default(handle);
					main_region_main_r1_freq1bar_react(handle, bool_false);
				}  else
				{
					if (handle->iface.eShortPress_raised == bool_true)
					{ 
						exseq_main_region_main_r1_freq1bar_vforow_Selected(handle);
						enseq_main_region_main_r1_freq1bar_vforow_SetMultiplier_default(handle);
						main_region_main_r1_freq1bar_react(handle, bool_false);
					}  else
					{
						did_transition = bool_false;
					}
				}
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_r1_freq1bar_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq1bar_vforow_SetMultiplier_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state SetMultiplier. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eShortPress_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq1bar_vforow_SetMultiplier(handle);
			enseq_main_region_main_r1_freq1bar_vforow_Selected_default(handle);
			main_region_main_r1_freq1bar_react(handle, bool_false);
		}  else
		{
			if (handle->iface.eClockWiseTick_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq1bar_vforow_SetMultiplier(handle);
				handle->iface.clock1Multiplier = (handle->iface.clock1Multiplier) != (1) ? handle->iface.clock1Multiplier / 10 : handle->iface.clock1Multiplier;
				enseq_main_region_main_r1_freq1bar_vforow_SetMultiplier_default(handle);
			}  else
			{
				if (handle->iface.eCounterClockWiseTick_raised == bool_true)
				{ 
					exseq_main_region_main_r1_freq1bar_vforow_SetMultiplier(handle);
					handle->iface.clock1Multiplier = (handle->iface.clock1Multiplier) != (1000000) ? handle->iface.clock1Multiplier * 10 : handle->iface.clock1Multiplier;
					enseq_main_region_main_r1_freq1bar_vforow_SetMultiplier_default(handle);
				}  else
				{
					if (handle->iface.eLongPress_raised == bool_true)
					{ 
						exseq_main_region_main_r1_freq1bar_vforow_SetMultiplier(handle);
						enseq_main_region_main_r1_freq1bar_vforow_Highlighted_default(handle);
						main_region_main_r1_freq1bar_react(handle, bool_false);
					}  else
					{
						did_transition = bool_false;
					}
				}
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_r1_freq1bar_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq2bar_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state freq2bar. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eClockWiseTick_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq2bar(handle);
			enseq_main_region_main_r1_menubar_default(handle);
			main_region_main_react(handle, bool_false);
		}  else
		{
			if (handle->iface.eCounterClockWiseTick_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq2bar(handle);
				enseq_main_region_main_r1_freq1bar_default(handle);
				main_region_main_react(handle, bool_false);
			}  else
			{
				did_transition = bool_false;
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq2bar_vforow_Highlighted_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state Highlighted. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eLongPress_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq2bar_vforow_Highlighted(handle);
			enseq_main_region_main_r1_freq2bar_vforow_Selected_default(handle);
			main_region_main_r1_freq2bar_react(handle, bool_false);
		}  else
		{
			if (handle->iface.eShortPress_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq2bar_vforow_Highlighted(handle);
				handle->internal.eClock2Toggle_raised = bool_true;
				enseq_main_region_main_r1_freq2bar_vforow_Highlighted_default(handle);
			}  else
			{
				did_transition = bool_false;
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_r1_freq2bar_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq2bar_vforow_Selected_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state Selected. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eCounterClockWiseTick_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq2bar_vforow_Selected(handle);
			handle->iface.clock2ReqFreq = handle->iface.clock2ReqFreq - handle->iface.clock2Multiplier;
			handle->internal.eClockUpdate_raised = bool_true;
			enseq_main_region_main_r1_freq2bar_vforow_Selected_default(handle);
		}  else
		{
			if (handle->iface.eClockWiseTick_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq2bar_vforow_Selected(handle);
				handle->iface.clock2ReqFreq = handle->iface.clock2ReqFreq + handle->iface.clock2Multiplier;
				handle->internal.eClockUpdate_raised = bool_true;
				enseq_main_region_main_r1_freq2bar_vforow_Selected_default(handle);
			}  else
			{
				if (handle->iface.eLongPress_raised == bool_true)
				{ 
					exseq_main_region_main_r1_freq2bar_vforow_Selected(handle);
					enseq_main_region_main_r1_freq2bar_vforow_Highlighted_default(handle);
					main_region_main_r1_freq2bar_react(handle, bool_false);
				}  else
				{
					if (handle->iface.eShortPress_raised == bool_true)
					{ 
						exseq_main_region_main_r1_freq2bar_vforow_Selected(handle);
						enseq_main_region_main_r1_freq2bar_vforow_SetMultiplier_default(handle);
						main_region_main_r1_freq2bar_react(handle, bool_false);
					}  else
					{
						did_transition = bool_false;
					}
				}
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_r1_freq2bar_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean main_region_main_r1_freq2bar_vforow_SetMultiplier_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state SetMultiplier. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->iface.eShortPress_raised == bool_true)
		{ 
			exseq_main_region_main_r1_freq2bar_vforow_SetMultiplier(handle);
			enseq_main_region_main_r1_freq2bar_vforow_Selected_default(handle);
			main_region_main_r1_freq2bar_react(handle, bool_false);
		}  else
		{
			if (handle->iface.eClockWiseTick_raised == bool_true)
			{ 
				exseq_main_region_main_r1_freq2bar_vforow_SetMultiplier(handle);
				handle->iface.clock2Multiplier = (handle->iface.clock2Multiplier) != (1) ? handle->iface.clock2Multiplier / 10 : handle->iface.clock2Multiplier;
				enseq_main_region_main_r1_freq2bar_vforow_SetMultiplier_default(handle);
			}  else
			{
				if (handle->iface.eCounterClockWiseTick_raised == bool_true)
				{ 
					exseq_main_region_main_r1_freq2bar_vforow_SetMultiplier(handle);
					handle->iface.clock2Multiplier = (handle->iface.clock2Multiplier) != (1000000) ? handle->iface.clock2Multiplier * 10 : handle->iface.clock2Multiplier;
					enseq_main_region_main_r1_freq2bar_vforow_SetMultiplier_default(handle);
				}  else
				{
					if (handle->iface.eLongPress_raised == bool_true)
					{ 
						exseq_main_region_main_r1_freq2bar_vforow_SetMultiplier(handle);
						enseq_main_region_main_r1_freq2bar_vforow_Highlighted_default(handle);
						main_region_main_r1_freq2bar_react(handle, bool_false);
					}  else
					{
						did_transition = bool_false;
					}
				}
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = main_region_main_r1_freq2bar_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean Generator_Initialize_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state Initialize. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->internal.eGeneratorInitialized_raised == bool_true)
		{ 
			exseq_Generator_Initialize(handle);
			enseq_Generator_Running_default(handle);
			react(handle, bool_false);
		}  else
		{
			did_transition = bool_false;
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean Generator_Running_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state Running. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		did_transition = bool_false;
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean Generator_Running_CLK0_Off_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state Off. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->internal.eClock0Toggle_raised == bool_true)
		{ 
			exseq_Generator_Running_CLK0_Off(handle);
			enseq_Generator_Running_CLK0_On_default(handle);
		}  else
		{
			did_transition = bool_false;
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
	} 
	return did_transition;
}

static sc_boolean Generator_Running_CLK0_On_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state On. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->internal.eClock0Toggle_raised == bool_true)
		{ 
			exseq_Generator_Running_CLK0_On(handle);
			enseq_Generator_Running_CLK0_Off_default(handle);
		}  else
		{
			if (handle->internal.eClockUpdate_raised == bool_true)
			{ 
				exseq_Generator_Running_CLK0_On(handle);
				defaultIface_updateClock(handle, 0);
				enseq_Generator_Running_CLK0_On_default(handle);
			}  else
			{
				did_transition = bool_false;
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
	} 
	return did_transition;
}

static sc_boolean Generator_Running_CLK1_Off_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state Off. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->internal.eClock1Toggle_raised == bool_true)
		{ 
			exseq_Generator_Running_CLK1_Off(handle);
			enseq_Generator_Running_CLK1_On_default(handle);
		}  else
		{
			did_transition = bool_false;
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
	} 
	return did_transition;
}

static sc_boolean Generator_Running_CLK1_On_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state On. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->internal.eClock1Toggle_raised == bool_true)
		{ 
			exseq_Generator_Running_CLK1_On(handle);
			enseq_Generator_Running_CLK1_Off_default(handle);
		}  else
		{
			if (handle->internal.eClockUpdate_raised == bool_true)
			{ 
				exseq_Generator_Running_CLK1_On(handle);
				defaultIface_updateClock(handle, 1);
				enseq_Generator_Running_CLK1_On_default(handle);
			}  else
			{
				did_transition = bool_false;
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
	} 
	return did_transition;
}

static sc_boolean Generator_Running_CLK2_Off_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state Off. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->internal.eClock2Toggle_raised == bool_true)
		{ 
			exseq_Generator_Running_CLK2_Off(handle);
			enseq_Generator_Running_CLK2_On_default(handle);
			Generator_Running_react(handle, bool_false);
		}  else
		{
			did_transition = bool_false;
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = Generator_Running_react(handle, try_transition);
	} 
	return did_transition;
}

static sc_boolean Generator_Running_CLK2_On_react(Default* handle, const sc_boolean try_transition) {
	/* The reactions of state On. */
	sc_boolean did_transition = try_transition;
	if (try_transition == bool_true)
	{ 
		if (handle->internal.eClock2Toggle_raised == bool_true)
		{ 
			exseq_Generator_Running_CLK2_On(handle);
			enseq_Generator_Running_CLK2_Off_default(handle);
			Generator_Running_react(handle, bool_false);
		}  else
		{
			if (handle->internal.eClockUpdate_raised == bool_true)
			{ 
				exseq_Generator_Running_CLK2_On(handle);
				defaultIface_updateClock(handle, 2);
				enseq_Generator_Running_CLK2_On_default(handle);
			}  else
			{
				did_transition = bool_false;
			}
		}
	} 
	if ((did_transition) == (bool_false))
	{ 
		did_transition = Generator_Running_react(handle, try_transition);
	} 
	return did_transition;
}


