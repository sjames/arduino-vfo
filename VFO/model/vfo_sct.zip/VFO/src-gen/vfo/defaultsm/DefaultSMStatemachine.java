package vfo.defaultsm;
import java.util.LinkedList;
import java.util.Queue;

public class DefaultSMStatemachine implements IDefaultSMStatemachine {

	protected class SCInterfaceImpl implements SCInterface {
	
		private boolean eReady;
		
		public void raiseEReady() {
			eReady = true;
			runCycle();
		}
		
		private boolean eShortPress;
		
		public void raiseEShortPress() {
			eShortPress = true;
			runCycle();
		}
		
		private boolean eLongPress;
		
		public void raiseELongPress() {
			eLongPress = true;
			runCycle();
		}
		
		private boolean eClockWiseTick;
		
		public void raiseEClockWiseTick() {
			eClockWiseTick = true;
			runCycle();
		}
		
		private boolean eCounterClockWiseTick;
		
		public void raiseECounterClockWiseTick() {
			eCounterClockWiseTick = true;
			runCycle();
		}
		
		private long clock0Freq;
		
		public long getClock0Freq() {
			return clock0Freq;
		}
		
		public void setClock0Freq(long value) {
			this.clock0Freq = value;
		}
		
		private long clock1Freq;
		
		public long getClock1Freq() {
			return clock1Freq;
		}
		
		public void setClock1Freq(long value) {
			this.clock1Freq = value;
		}
		
		private long clock2Freq;
		
		public long getClock2Freq() {
			return clock2Freq;
		}
		
		public void setClock2Freq(long value) {
			this.clock2Freq = value;
		}
		
		private long clock0ReqFreq;
		
		public long getClock0ReqFreq() {
			return clock0ReqFreq;
		}
		
		public void setClock0ReqFreq(long value) {
			this.clock0ReqFreq = value;
		}
		
		private long clock1ReqFreq;
		
		public long getClock1ReqFreq() {
			return clock1ReqFreq;
		}
		
		public void setClock1ReqFreq(long value) {
			this.clock1ReqFreq = value;
		}
		
		private long clock2ReqFreq;
		
		public long getClock2ReqFreq() {
			return clock2ReqFreq;
		}
		
		public void setClock2ReqFreq(long value) {
			this.clock2ReqFreq = value;
		}
		
		private long clock0Multiplier;
		
		public long getClock0Multiplier() {
			return clock0Multiplier;
		}
		
		public void setClock0Multiplier(long value) {
			this.clock0Multiplier = value;
		}
		
		private long clock1Multiplier;
		
		public long getClock1Multiplier() {
			return clock1Multiplier;
		}
		
		public void setClock1Multiplier(long value) {
			this.clock1Multiplier = value;
		}
		
		private long clock2Multiplier;
		
		public long getClock2Multiplier() {
			return clock2Multiplier;
		}
		
		public void setClock2Multiplier(long value) {
			this.clock2Multiplier = value;
		}
		
		protected void clearEvents() {
			eReady = false;
			eShortPress = false;
			eLongPress = false;
			eClockWiseTick = false;
			eCounterClockWiseTick = false;
		}
	}
	
	protected SCInterfaceImpl sCInterface;
	
	private boolean initialized = false;
	
	public enum State {
		main_region_initialize,
		main_region_main,
		main_region_main_r1_menubar,
		main_region_main_r1_freq0bar,
		main_region_main_r1_freq0bar_vforow_Highlighted,
		main_region_main_r1_freq0bar_vforow_Selected,
		main_region_main_r1_freq0bar_vforow_SetMultiplier,
		main_region_main_r1_freq1bar,
		main_region_main_r1_freq2bar,
		generator_Initialize,
		generator_Running,
		generator_Running_CLK0_Off,
		generator_Running_CLK0_On,
		generator_Running_CLK1_Off,
		generator_Running_CLK1_On,
		generator_Running_CLK2_Off,
		generator_Running_CLK2_On,
		$NullState$
	};
	
	private final State[] stateVector = new State[4];
	
	private int nextStateIndex;
	
	private Queue<Runnable> internalEventQueue = new LinkedList<Runnable>();
	
	private boolean eGeneratorInitialized;
	
	private boolean eClock0Toggle;
	
	private boolean eClock1Toggle;
	
	private boolean eClock2Toggle;
	
	private boolean eClockUpdate;
	public DefaultSMStatemachine() {
		sCInterface = new SCInterfaceImpl();
	}
	
	public void init() {
		this.initialized = true;
		for (int i = 0; i < 4; i++) {
			stateVector[i] = State.$NullState$;
		}
		clearEvents();
		clearOutEvents();
		sCInterface.setClock0Freq(0);
		
		sCInterface.setClock1Freq(0);
		
		sCInterface.setClock2Freq(0);
		
		sCInterface.setClock0ReqFreq(0);
		
		sCInterface.setClock1ReqFreq(0);
		
		sCInterface.setClock2ReqFreq(0);
		
		sCInterface.setClock0Multiplier(1);
		
		sCInterface.setClock1Multiplier(1);
		
		sCInterface.setClock2Multiplier(1);
	}
	
	public void enter() {
		if (!initialized) {
			throw new IllegalStateException(
					"The state machine needs to be initialized first by calling the init() function.");
		}
		enterSequence_main_region_default();
		enterSequence_Generator_default();
	}
	
	public void exit() {
		exitSequence_main_region();
		exitSequence_Generator();
	}
	
	/**
	 * @see IStatemachine#isActive()
	 */
	public boolean isActive() {
		return stateVector[0] != State.$NullState$||stateVector[1] != State.$NullState$||stateVector[2] != State.$NullState$||stateVector[3] != State.$NullState$;
	}
	
	/** 
	* Always returns 'false' since this state machine can never become final.
	*
	* @see IStatemachine#isFinal()
	*/
	public boolean isFinal() {
		return false;
	}
	/**
	* This method resets the incoming events (time events included).
	*/
	protected void clearEvents() {
		sCInterface.clearEvents();
		eGeneratorInitialized = false;
		eClock0Toggle = false;
		eClock1Toggle = false;
		eClock2Toggle = false;
		eClockUpdate = false;
	}
	
	/**
	* This method resets the outgoing events.
	*/
	protected void clearOutEvents() {
	}
	
	/**
	* Returns true if the given state is currently active otherwise false.
	*/
	public boolean isStateActive(State state) {
	
		switch (state) {
		case main_region_initialize:
			return stateVector[0] == State.main_region_initialize;
		case main_region_main:
			return stateVector[0].ordinal() >= State.
					main_region_main.ordinal()&& stateVector[0].ordinal() <= State.main_region_main_r1_freq2bar.ordinal();
		case main_region_main_r1_menubar:
			return stateVector[0] == State.main_region_main_r1_menubar;
		case main_region_main_r1_freq0bar:
			return stateVector[0].ordinal() >= State.
					main_region_main_r1_freq0bar.ordinal()&& stateVector[0].ordinal() <= State.main_region_main_r1_freq0bar_vforow_SetMultiplier.ordinal();
		case main_region_main_r1_freq0bar_vforow_Highlighted:
			return stateVector[0] == State.main_region_main_r1_freq0bar_vforow_Highlighted;
		case main_region_main_r1_freq0bar_vforow_Selected:
			return stateVector[0] == State.main_region_main_r1_freq0bar_vforow_Selected;
		case main_region_main_r1_freq0bar_vforow_SetMultiplier:
			return stateVector[0] == State.main_region_main_r1_freq0bar_vforow_SetMultiplier;
		case main_region_main_r1_freq1bar:
			return stateVector[0] == State.main_region_main_r1_freq1bar;
		case main_region_main_r1_freq2bar:
			return stateVector[0] == State.main_region_main_r1_freq2bar;
		case generator_Initialize:
			return stateVector[1] == State.generator_Initialize;
		case generator_Running:
			return stateVector[1].ordinal() >= State.
					generator_Running.ordinal()&& stateVector[1].ordinal() <= State.generator_Running_CLK2_On.ordinal();
		case generator_Running_CLK0_Off:
			return stateVector[1] == State.generator_Running_CLK0_Off;
		case generator_Running_CLK0_On:
			return stateVector[1] == State.generator_Running_CLK0_On;
		case generator_Running_CLK1_Off:
			return stateVector[2] == State.generator_Running_CLK1_Off;
		case generator_Running_CLK1_On:
			return stateVector[2] == State.generator_Running_CLK1_On;
		case generator_Running_CLK2_Off:
			return stateVector[3] == State.generator_Running_CLK2_Off;
		case generator_Running_CLK2_On:
			return stateVector[3] == State.generator_Running_CLK2_On;
		default:
			return false;
		}
	}
	
	public SCInterface getSCInterface() {
		return sCInterface;
	}
	
	private void raiseEGeneratorInitialized() {
	
		internalEventQueue.add( new Runnable() {
			@Override public void run() {
				eGeneratorInitialized = true;					
				singleCycle();
			}
		});
	}
	
	
	private void raiseEClock0Toggle() {
	
		internalEventQueue.add( new Runnable() {
			@Override public void run() {
				eClock0Toggle = true;					
				singleCycle();
			}
		});
	}
	
	
	private void raiseEClock1Toggle() {
	
		internalEventQueue.add( new Runnable() {
			@Override public void run() {
				eClock1Toggle = true;					
				singleCycle();
			}
		});
	}
	
	
	private void raiseEClock2Toggle() {
	
		internalEventQueue.add( new Runnable() {
			@Override public void run() {
				eClock2Toggle = true;					
				singleCycle();
			}
		});
	}
	
	
	private void raiseEClockUpdate() {
	
		internalEventQueue.add( new Runnable() {
			@Override public void run() {
				eClockUpdate = true;					
				singleCycle();
			}
		});
	}
	
	
	public void raiseEReady() {
		sCInterface.raiseEReady();
	}
	
	public void raiseEShortPress() {
		sCInterface.raiseEShortPress();
	}
	
	public void raiseELongPress() {
		sCInterface.raiseELongPress();
	}
	
	public void raiseEClockWiseTick() {
		sCInterface.raiseEClockWiseTick();
	}
	
	public void raiseECounterClockWiseTick() {
		sCInterface.raiseECounterClockWiseTick();
	}
	
	public long getClock0Freq() {
		return sCInterface.getClock0Freq();
	}
	
	public void setClock0Freq(long value) {
		sCInterface.setClock0Freq(value);
	}
	
	public long getClock1Freq() {
		return sCInterface.getClock1Freq();
	}
	
	public void setClock1Freq(long value) {
		sCInterface.setClock1Freq(value);
	}
	
	public long getClock2Freq() {
		return sCInterface.getClock2Freq();
	}
	
	public void setClock2Freq(long value) {
		sCInterface.setClock2Freq(value);
	}
	
	public long getClock0ReqFreq() {
		return sCInterface.getClock0ReqFreq();
	}
	
	public void setClock0ReqFreq(long value) {
		sCInterface.setClock0ReqFreq(value);
	}
	
	public long getClock1ReqFreq() {
		return sCInterface.getClock1ReqFreq();
	}
	
	public void setClock1ReqFreq(long value) {
		sCInterface.setClock1ReqFreq(value);
	}
	
	public long getClock2ReqFreq() {
		return sCInterface.getClock2ReqFreq();
	}
	
	public void setClock2ReqFreq(long value) {
		sCInterface.setClock2ReqFreq(value);
	}
	
	public long getClock0Multiplier() {
		return sCInterface.getClock0Multiplier();
	}
	
	public void setClock0Multiplier(long value) {
		sCInterface.setClock0Multiplier(value);
	}
	
	public long getClock1Multiplier() {
		return sCInterface.getClock1Multiplier();
	}
	
	public void setClock1Multiplier(long value) {
		sCInterface.setClock1Multiplier(value);
	}
	
	public long getClock2Multiplier() {
		return sCInterface.getClock2Multiplier();
	}
	
	public void setClock2Multiplier(long value) {
		sCInterface.setClock2Multiplier(value);
	}
	
	/* Entry action for state 'Initialize'. */
	private void entryAction_Generator_Initialize() {
		raiseEGeneratorInitialized();
	}
	
	/* 'default' enter sequence for state initialize */
	private void enterSequence_main_region_initialize_default() {
		nextStateIndex = 0;
		stateVector[0] = State.main_region_initialize;
	}
	
	/* 'default' enter sequence for state main */
	private void enterSequence_main_region_main_default() {
		enterSequence_main_region_main_r1_default();
	}
	
	/* 'default' enter sequence for state menubar */
	private void enterSequence_main_region_main_r1_menubar_default() {
		nextStateIndex = 0;
		stateVector[0] = State.main_region_main_r1_menubar;
	}
	
	/* 'default' enter sequence for state freq0bar */
	private void enterSequence_main_region_main_r1_freq0bar_default() {
		enterSequence_main_region_main_r1_freq0bar_vforow_default();
	}
	
	/* 'default' enter sequence for state Highlighted */
	private void enterSequence_main_region_main_r1_freq0bar_vforow_Highlighted_default() {
		nextStateIndex = 0;
		stateVector[0] = State.main_region_main_r1_freq0bar_vforow_Highlighted;
	}
	
	/* 'default' enter sequence for state Selected */
	private void enterSequence_main_region_main_r1_freq0bar_vforow_Selected_default() {
		nextStateIndex = 0;
		stateVector[0] = State.main_region_main_r1_freq0bar_vforow_Selected;
	}
	
	/* 'default' enter sequence for state SetMultiplier */
	private void enterSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier_default() {
		nextStateIndex = 0;
		stateVector[0] = State.main_region_main_r1_freq0bar_vforow_SetMultiplier;
	}
	
	/* 'default' enter sequence for state freq1bar */
	private void enterSequence_main_region_main_r1_freq1bar_default() {
		nextStateIndex = 0;
		stateVector[0] = State.main_region_main_r1_freq1bar;
	}
	
	/* 'default' enter sequence for state freq2bar */
	private void enterSequence_main_region_main_r1_freq2bar_default() {
		nextStateIndex = 0;
		stateVector[0] = State.main_region_main_r1_freq2bar;
	}
	
	/* 'default' enter sequence for state Initialize */
	private void enterSequence_Generator_Initialize_default() {
		entryAction_Generator_Initialize();
		nextStateIndex = 1;
		stateVector[1] = State.generator_Initialize;
	}
	
	/* 'default' enter sequence for state Running */
	private void enterSequence_Generator_Running_default() {
		enterSequence_Generator_Running_CLK0_default();
		enterSequence_Generator_Running_CLK1_default();
		enterSequence_Generator_Running_CLK2_default();
	}
	
	/* 'default' enter sequence for state Off */
	private void enterSequence_Generator_Running_CLK0_Off_default() {
		nextStateIndex = 1;
		stateVector[1] = State.generator_Running_CLK0_Off;
	}
	
	/* 'default' enter sequence for state On */
	private void enterSequence_Generator_Running_CLK0_On_default() {
		nextStateIndex = 1;
		stateVector[1] = State.generator_Running_CLK0_On;
	}
	
	/* 'default' enter sequence for state Off */
	private void enterSequence_Generator_Running_CLK1_Off_default() {
		nextStateIndex = 2;
		stateVector[2] = State.generator_Running_CLK1_Off;
	}
	
	/* 'default' enter sequence for state On */
	private void enterSequence_Generator_Running_CLK1_On_default() {
		nextStateIndex = 2;
		stateVector[2] = State.generator_Running_CLK1_On;
	}
	
	/* 'default' enter sequence for state Off */
	private void enterSequence_Generator_Running_CLK2_Off_default() {
		nextStateIndex = 3;
		stateVector[3] = State.generator_Running_CLK2_Off;
	}
	
	/* 'default' enter sequence for state On */
	private void enterSequence_Generator_Running_CLK2_On_default() {
		nextStateIndex = 3;
		stateVector[3] = State.generator_Running_CLK2_On;
	}
	
	/* 'default' enter sequence for region main region */
	private void enterSequence_main_region_default() {
		react_main_region__entry_Default();
	}
	
	/* 'default' enter sequence for region r1 */
	private void enterSequence_main_region_main_r1_default() {
		react_main_region_main_r1__entry_Default();
	}
	
	/* 'default' enter sequence for region vforow */
	private void enterSequence_main_region_main_r1_freq0bar_vforow_default() {
		react_main_region_main_r1_freq0bar_vforow__entry_Default();
	}
	
	/* 'default' enter sequence for region Generator */
	private void enterSequence_Generator_default() {
		react_Generator__entry_Default();
	}
	
	/* 'default' enter sequence for region CLK0 */
	private void enterSequence_Generator_Running_CLK0_default() {
		react_Generator_Running_CLK0__entry_Default();
	}
	
	/* 'default' enter sequence for region CLK1 */
	private void enterSequence_Generator_Running_CLK1_default() {
		react_Generator_Running_CLK1__entry_Default();
	}
	
	/* 'default' enter sequence for region CLK2 */
	private void enterSequence_Generator_Running_CLK2_default() {
		react_Generator_Running_CLK2__entry_Default();
	}
	
	/* Default exit sequence for state initialize */
	private void exitSequence_main_region_initialize() {
		nextStateIndex = 0;
		stateVector[0] = State.$NullState$;
	}
	
	/* Default exit sequence for state menubar */
	private void exitSequence_main_region_main_r1_menubar() {
		nextStateIndex = 0;
		stateVector[0] = State.$NullState$;
	}
	
	/* Default exit sequence for state freq0bar */
	private void exitSequence_main_region_main_r1_freq0bar() {
		exitSequence_main_region_main_r1_freq0bar_vforow();
	}
	
	/* Default exit sequence for state Highlighted */
	private void exitSequence_main_region_main_r1_freq0bar_vforow_Highlighted() {
		nextStateIndex = 0;
		stateVector[0] = State.$NullState$;
	}
	
	/* Default exit sequence for state Selected */
	private void exitSequence_main_region_main_r1_freq0bar_vforow_Selected() {
		nextStateIndex = 0;
		stateVector[0] = State.$NullState$;
	}
	
	/* Default exit sequence for state SetMultiplier */
	private void exitSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier() {
		nextStateIndex = 0;
		stateVector[0] = State.$NullState$;
	}
	
	/* Default exit sequence for state freq1bar */
	private void exitSequence_main_region_main_r1_freq1bar() {
		nextStateIndex = 0;
		stateVector[0] = State.$NullState$;
	}
	
	/* Default exit sequence for state freq2bar */
	private void exitSequence_main_region_main_r1_freq2bar() {
		nextStateIndex = 0;
		stateVector[0] = State.$NullState$;
	}
	
	/* Default exit sequence for state Initialize */
	private void exitSequence_Generator_Initialize() {
		nextStateIndex = 1;
		stateVector[1] = State.$NullState$;
	}
	
	/* Default exit sequence for state Off */
	private void exitSequence_Generator_Running_CLK0_Off() {
		nextStateIndex = 1;
		stateVector[1] = State.$NullState$;
	}
	
	/* Default exit sequence for state On */
	private void exitSequence_Generator_Running_CLK0_On() {
		nextStateIndex = 1;
		stateVector[1] = State.$NullState$;
	}
	
	/* Default exit sequence for state Off */
	private void exitSequence_Generator_Running_CLK1_Off() {
		nextStateIndex = 2;
		stateVector[2] = State.$NullState$;
	}
	
	/* Default exit sequence for state On */
	private void exitSequence_Generator_Running_CLK1_On() {
		nextStateIndex = 2;
		stateVector[2] = State.$NullState$;
	}
	
	/* Default exit sequence for state Off */
	private void exitSequence_Generator_Running_CLK2_Off() {
		nextStateIndex = 3;
		stateVector[3] = State.$NullState$;
	}
	
	/* Default exit sequence for state On */
	private void exitSequence_Generator_Running_CLK2_On() {
		nextStateIndex = 3;
		stateVector[3] = State.$NullState$;
	}
	
	/* Default exit sequence for region main region */
	private void exitSequence_main_region() {
		switch (stateVector[0]) {
		case main_region_initialize:
			exitSequence_main_region_initialize();
			break;
		case main_region_main_r1_menubar:
			exitSequence_main_region_main_r1_menubar();
			break;
		case main_region_main_r1_freq0bar_vforow_Highlighted:
			exitSequence_main_region_main_r1_freq0bar_vforow_Highlighted();
			break;
		case main_region_main_r1_freq0bar_vforow_Selected:
			exitSequence_main_region_main_r1_freq0bar_vforow_Selected();
			break;
		case main_region_main_r1_freq0bar_vforow_SetMultiplier:
			exitSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier();
			break;
		case main_region_main_r1_freq1bar:
			exitSequence_main_region_main_r1_freq1bar();
			break;
		case main_region_main_r1_freq2bar:
			exitSequence_main_region_main_r1_freq2bar();
			break;
		default:
			break;
		}
	}
	
	/* Default exit sequence for region r1 */
	private void exitSequence_main_region_main_r1() {
		switch (stateVector[0]) {
		case main_region_main_r1_menubar:
			exitSequence_main_region_main_r1_menubar();
			break;
		case main_region_main_r1_freq0bar_vforow_Highlighted:
			exitSequence_main_region_main_r1_freq0bar_vforow_Highlighted();
			break;
		case main_region_main_r1_freq0bar_vforow_Selected:
			exitSequence_main_region_main_r1_freq0bar_vforow_Selected();
			break;
		case main_region_main_r1_freq0bar_vforow_SetMultiplier:
			exitSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier();
			break;
		case main_region_main_r1_freq1bar:
			exitSequence_main_region_main_r1_freq1bar();
			break;
		case main_region_main_r1_freq2bar:
			exitSequence_main_region_main_r1_freq2bar();
			break;
		default:
			break;
		}
	}
	
	/* Default exit sequence for region vforow */
	private void exitSequence_main_region_main_r1_freq0bar_vforow() {
		switch (stateVector[0]) {
		case main_region_main_r1_freq0bar_vforow_Highlighted:
			exitSequence_main_region_main_r1_freq0bar_vforow_Highlighted();
			break;
		case main_region_main_r1_freq0bar_vforow_Selected:
			exitSequence_main_region_main_r1_freq0bar_vforow_Selected();
			break;
		case main_region_main_r1_freq0bar_vforow_SetMultiplier:
			exitSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier();
			break;
		default:
			break;
		}
	}
	
	/* Default exit sequence for region Generator */
	private void exitSequence_Generator() {
		switch (stateVector[1]) {
		case generator_Initialize:
			exitSequence_Generator_Initialize();
			break;
		case generator_Running_CLK0_Off:
			exitSequence_Generator_Running_CLK0_Off();
			break;
		case generator_Running_CLK0_On:
			exitSequence_Generator_Running_CLK0_On();
			break;
		default:
			break;
		}
		
		switch (stateVector[2]) {
		case generator_Running_CLK1_Off:
			exitSequence_Generator_Running_CLK1_Off();
			break;
		case generator_Running_CLK1_On:
			exitSequence_Generator_Running_CLK1_On();
			break;
		default:
			break;
		}
		
		switch (stateVector[3]) {
		case generator_Running_CLK2_Off:
			exitSequence_Generator_Running_CLK2_Off();
			break;
		case generator_Running_CLK2_On:
			exitSequence_Generator_Running_CLK2_On();
			break;
		default:
			break;
		}
	}
	
	/* Default exit sequence for region CLK0 */
	private void exitSequence_Generator_Running_CLK0() {
		switch (stateVector[1]) {
		case generator_Running_CLK0_Off:
			exitSequence_Generator_Running_CLK0_Off();
			break;
		case generator_Running_CLK0_On:
			exitSequence_Generator_Running_CLK0_On();
			break;
		default:
			break;
		}
	}
	
	/* Default exit sequence for region CLK1 */
	private void exitSequence_Generator_Running_CLK1() {
		switch (stateVector[2]) {
		case generator_Running_CLK1_Off:
			exitSequence_Generator_Running_CLK1_Off();
			break;
		case generator_Running_CLK1_On:
			exitSequence_Generator_Running_CLK1_On();
			break;
		default:
			break;
		}
	}
	
	/* Default exit sequence for region CLK2 */
	private void exitSequence_Generator_Running_CLK2() {
		switch (stateVector[3]) {
		case generator_Running_CLK2_Off:
			exitSequence_Generator_Running_CLK2_Off();
			break;
		case generator_Running_CLK2_On:
			exitSequence_Generator_Running_CLK2_On();
			break;
		default:
			break;
		}
	}
	
	/* Default react sequence for initial entry  */
	private void react_main_region__entry_Default() {
		enterSequence_main_region_initialize_default();
	}
	
	/* Default react sequence for initial entry  */
	private void react_main_region_main_r1_freq0bar_vforow__entry_Default() {
		enterSequence_main_region_main_r1_freq0bar_vforow_Highlighted_default();
	}
	
	/* Default react sequence for initial entry  */
	private void react_main_region_main_r1__entry_Default() {
		enterSequence_main_region_main_r1_freq0bar_default();
	}
	
	/* Default react sequence for initial entry  */
	private void react_Generator__entry_Default() {
		enterSequence_Generator_Initialize_default();
	}
	
	/* Default react sequence for initial entry  */
	private void react_Generator_Running_CLK0__entry_Default() {
		enterSequence_Generator_Running_CLK0_Off_default();
	}
	
	/* Default react sequence for initial entry  */
	private void react_Generator_Running_CLK1__entry_Default() {
		enterSequence_Generator_Running_CLK1_Off_default();
	}
	
	/* Default react sequence for initial entry  */
	private void react_Generator_Running_CLK2__entry_Default() {
		enterSequence_Generator_Running_CLK2_Off_default();
	}
	
	private boolean react(boolean try_transition) {
		return false;
	}
	
	private boolean main_region_initialize_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (sCInterface.eReady) {
				exitSequence_main_region_initialize();
				enterSequence_main_region_main_default();
			} else {
				did_transition = false;
			}
		}
		if (did_transition==false) {
		}
		return did_transition;
	}
	
	private boolean main_region_main_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			did_transition = false;
		}
		if (did_transition==false) {
		}
		return did_transition;
	}
	
	private boolean main_region_main_r1_menubar_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (sCInterface.eCounterClockWiseTick) {
				exitSequence_main_region_main_r1_menubar();
				enterSequence_main_region_main_r1_freq2bar_default();
				main_region_main_react(false);
			} else {
				did_transition = false;
			}
		}
		if (did_transition==false) {
			did_transition = main_region_main_react(try_transition);
		}
		return did_transition;
	}
	
	private boolean main_region_main_r1_freq0bar_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (sCInterface.eCounterClockWiseTick) {
				exitSequence_main_region_main_r1_freq0bar();
				enterSequence_main_region_main_r1_menubar_default();
				main_region_main_react(false);
			} else {
				if (sCInterface.eClockWiseTick) {
					exitSequence_main_region_main_r1_freq0bar();
					enterSequence_main_region_main_r1_freq1bar_default();
					main_region_main_react(false);
				} else {
					did_transition = false;
				}
			}
		}
		if (did_transition==false) {
			did_transition = main_region_main_react(try_transition);
		}
		return did_transition;
	}
	
	private boolean main_region_main_r1_freq0bar_vforow_Highlighted_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (sCInterface.eLongPress) {
				exitSequence_main_region_main_r1_freq0bar_vforow_Highlighted();
				enterSequence_main_region_main_r1_freq0bar_vforow_Selected_default();
				main_region_main_r1_freq0bar_react(false);
			} else {
				if (sCInterface.eShortPress) {
					exitSequence_main_region_main_r1_freq0bar_vforow_Highlighted();
					raiseEClock0Toggle();
					
					enterSequence_main_region_main_r1_freq0bar_vforow_Highlighted_default();
				} else {
					did_transition = false;
				}
			}
		}
		if (did_transition==false) {
			did_transition = main_region_main_r1_freq0bar_react(try_transition);
		}
		return did_transition;
	}
	
	private boolean main_region_main_r1_freq0bar_vforow_Selected_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (sCInterface.eCounterClockWiseTick) {
				exitSequence_main_region_main_r1_freq0bar_vforow_Selected();
				sCInterface.setClock0ReqFreq(sCInterface.clock0ReqFreq - sCInterface.clock0Multiplier);
				
				raiseEClockUpdate();
				
				enterSequence_main_region_main_r1_freq0bar_vforow_Selected_default();
			} else {
				if (sCInterface.eClockWiseTick) {
					exitSequence_main_region_main_r1_freq0bar_vforow_Selected();
					sCInterface.setClock0ReqFreq(sCInterface.clock0ReqFreq + sCInterface.clock0Multiplier);
					
					raiseEClockUpdate();
					
					enterSequence_main_region_main_r1_freq0bar_vforow_Selected_default();
				} else {
					if (sCInterface.eLongPress) {
						exitSequence_main_region_main_r1_freq0bar_vforow_Selected();
						enterSequence_main_region_main_r1_freq0bar_vforow_Highlighted_default();
						main_region_main_r1_freq0bar_react(false);
					} else {
						if (sCInterface.eShortPress) {
							exitSequence_main_region_main_r1_freq0bar_vforow_Selected();
							enterSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier_default();
							main_region_main_r1_freq0bar_react(false);
						} else {
							did_transition = false;
						}
					}
				}
			}
		}
		if (did_transition==false) {
			did_transition = main_region_main_r1_freq0bar_react(try_transition);
		}
		return did_transition;
	}
	
	private boolean main_region_main_r1_freq0bar_vforow_SetMultiplier_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (sCInterface.eShortPress) {
				exitSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier();
				enterSequence_main_region_main_r1_freq0bar_vforow_Selected_default();
				main_region_main_r1_freq0bar_react(false);
			} else {
				if (sCInterface.eClockWiseTick) {
					exitSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier();
					sCInterface.setClock0Multiplier(sCInterface.clock0Multiplier!=1 ? sCInterface.clock0Multiplier / 10 : sCInterface.clock0Multiplier);
					
					enterSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier_default();
				} else {
					if (sCInterface.eCounterClockWiseTick) {
						exitSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier();
						sCInterface.setClock0Multiplier(sCInterface.clock0Multiplier!=1000000 ? sCInterface.clock0Multiplier * 10 : sCInterface.clock0Multiplier);
						
						enterSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier_default();
					} else {
						if (sCInterface.eLongPress) {
							exitSequence_main_region_main_r1_freq0bar_vforow_SetMultiplier();
							enterSequence_main_region_main_r1_freq0bar_vforow_Highlighted_default();
							main_region_main_r1_freq0bar_react(false);
						} else {
							did_transition = false;
						}
					}
				}
			}
		}
		if (did_transition==false) {
			did_transition = main_region_main_r1_freq0bar_react(try_transition);
		}
		return did_transition;
	}
	
	private boolean main_region_main_r1_freq1bar_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (sCInterface.eClockWiseTick) {
				exitSequence_main_region_main_r1_freq1bar();
				enterSequence_main_region_main_r1_freq2bar_default();
				main_region_main_react(false);
			} else {
				if (sCInterface.eCounterClockWiseTick) {
					exitSequence_main_region_main_r1_freq1bar();
					enterSequence_main_region_main_r1_freq0bar_default();
					main_region_main_react(false);
				} else {
					did_transition = false;
				}
			}
		}
		if (did_transition==false) {
			did_transition = main_region_main_react(try_transition);
		}
		return did_transition;
	}
	
	private boolean main_region_main_r1_freq2bar_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (sCInterface.eClockWiseTick) {
				exitSequence_main_region_main_r1_freq2bar();
				enterSequence_main_region_main_r1_menubar_default();
				main_region_main_react(false);
			} else {
				if (sCInterface.eCounterClockWiseTick) {
					exitSequence_main_region_main_r1_freq2bar();
					enterSequence_main_region_main_r1_freq1bar_default();
					main_region_main_react(false);
				} else {
					did_transition = false;
				}
			}
		}
		if (did_transition==false) {
			did_transition = main_region_main_react(try_transition);
		}
		return did_transition;
	}
	
	private boolean generator_Initialize_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (eGeneratorInitialized) {
				exitSequence_Generator_Initialize();
				enterSequence_Generator_Running_default();
				react(false);
			} else {
				did_transition = false;
			}
		}
		if (did_transition==false) {
			did_transition = react(try_transition);
		}
		return did_transition;
	}
	
	private boolean generator_Running_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			did_transition = false;
		}
		if (did_transition==false) {
			did_transition = react(try_transition);
		}
		return did_transition;
	}
	
	private boolean generator_Running_CLK0_Off_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (eClock0Toggle) {
				exitSequence_Generator_Running_CLK0_Off();
				enterSequence_Generator_Running_CLK0_On_default();
			} else {
				did_transition = false;
			}
		}
		if (did_transition==false) {
		}
		return did_transition;
	}
	
	private boolean generator_Running_CLK0_On_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (eClock0Toggle) {
				exitSequence_Generator_Running_CLK0_On();
				enterSequence_Generator_Running_CLK0_Off_default();
			} else {
				if (eClockUpdate) {
					exitSequence_Generator_Running_CLK0_On();
					enterSequence_Generator_Running_CLK0_On_default();
				} else {
					did_transition = false;
				}
			}
		}
		if (did_transition==false) {
		}
		return did_transition;
	}
	
	private boolean generator_Running_CLK1_Off_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (eClock1Toggle) {
				exitSequence_Generator_Running_CLK1_Off();
				enterSequence_Generator_Running_CLK1_On_default();
			} else {
				did_transition = false;
			}
		}
		if (did_transition==false) {
		}
		return did_transition;
	}
	
	private boolean generator_Running_CLK1_On_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (eClock1Toggle) {
				exitSequence_Generator_Running_CLK1_On();
				enterSequence_Generator_Running_CLK1_Off_default();
			} else {
				if (eClockUpdate) {
					exitSequence_Generator_Running_CLK1_On();
					enterSequence_Generator_Running_CLK1_On_default();
				} else {
					did_transition = false;
				}
			}
		}
		if (did_transition==false) {
		}
		return did_transition;
	}
	
	private boolean generator_Running_CLK2_Off_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (eClock2Toggle) {
				exitSequence_Generator_Running_CLK2_Off();
				enterSequence_Generator_Running_CLK2_On_default();
				generator_Running_react(false);
			} else {
				did_transition = false;
			}
		}
		if (did_transition==false) {
			did_transition = generator_Running_react(try_transition);
		}
		return did_transition;
	}
	
	private boolean generator_Running_CLK2_On_react(boolean try_transition) {
		boolean did_transition = try_transition;
		
		if (try_transition) {
			if (eClock2Toggle) {
				exitSequence_Generator_Running_CLK2_On();
				enterSequence_Generator_Running_CLK2_Off_default();
				generator_Running_react(false);
			} else {
				if (eClockUpdate) {
					exitSequence_Generator_Running_CLK2_On();
					enterSequence_Generator_Running_CLK2_On_default();
				} else {
					did_transition = false;
				}
			}
		}
		if (did_transition==false) {
			did_transition = generator_Running_react(try_transition);
		}
		return did_transition;
	}
	
	public void runCycle() {
		if (!initialized)
			throw new IllegalStateException(
					"The state machine needs to be initialized first by calling the init() function.");
	
		clearOutEvents();
		singleCycle();
		clearEvents();
		
		// process queued events
		while (internalEventQueue.size() > 0) {
			internalEventQueue.poll().run();
			clearEvents();
		}
	}
	
	protected void singleCycle() {
		for (nextStateIndex = 0; nextStateIndex < stateVector.length; nextStateIndex++) {
			switch (stateVector[nextStateIndex]) {
			case main_region_initialize:
				main_region_initialize_react(true);
				break;
			case main_region_main_r1_menubar:
				main_region_main_r1_menubar_react(true);
				break;
			case main_region_main_r1_freq0bar_vforow_Highlighted:
				main_region_main_r1_freq0bar_vforow_Highlighted_react(true);
				break;
			case main_region_main_r1_freq0bar_vforow_Selected:
				main_region_main_r1_freq0bar_vforow_Selected_react(true);
				break;
			case main_region_main_r1_freq0bar_vforow_SetMultiplier:
				main_region_main_r1_freq0bar_vforow_SetMultiplier_react(true);
				break;
			case main_region_main_r1_freq1bar:
				main_region_main_r1_freq1bar_react(true);
				break;
			case main_region_main_r1_freq2bar:
				main_region_main_r1_freq2bar_react(true);
				break;
			case generator_Initialize:
				generator_Initialize_react(true);
				break;
			case generator_Running_CLK0_Off:
				generator_Running_CLK0_Off_react(true);
				break;
			case generator_Running_CLK0_On:
				generator_Running_CLK0_On_react(true);
				break;
			case generator_Running_CLK1_Off:
				generator_Running_CLK1_Off_react(true);
				break;
			case generator_Running_CLK1_On:
				generator_Running_CLK1_On_react(true);
				break;
			case generator_Running_CLK2_Off:
				generator_Running_CLK2_Off_react(true);
				break;
			case generator_Running_CLK2_On:
				generator_Running_CLK2_On_react(true);
				break;
			default:
				// $NullState$
			}
		}
	}
}
