package vfo.defaultsm;

import vfo.IStatemachine;

public interface IDefaultSMStatemachine extends IStatemachine {

	public interface SCInterface {
	
		public void raiseEReady();
		
		public void raiseEShortPress();
		
		public void raiseELongPress();
		
		public void raiseEClockWiseTick();
		
		public void raiseECounterClockWiseTick();
		
		public long getClock0Freq();
		
		public void setClock0Freq(long value);
		
		public long getClock1Freq();
		
		public void setClock1Freq(long value);
		
		public long getClock2Freq();
		
		public void setClock2Freq(long value);
		
		public long getClock0ReqFreq();
		
		public void setClock0ReqFreq(long value);
		
		public long getClock1ReqFreq();
		
		public void setClock1ReqFreq(long value);
		
		public long getClock2ReqFreq();
		
		public void setClock2ReqFreq(long value);
		
		public long getClock0Multiplier();
		
		public void setClock0Multiplier(long value);
		
		public long getClock1Multiplier();
		
		public void setClock1Multiplier(long value);
		
		public long getClock2Multiplier();
		
		public void setClock2Multiplier(long value);
		
	}
	
	public SCInterface getSCInterface();
	
}
